// @ts-ignore
const getActiveView = (routes: RoutesType[]): { name; View; secondary } => {
  let View = null;
  let name = 'Default Path Text';
  let secondary = false;
  for (let i = 0; i < routes.length; i++) {
    const { dir, subDir } = routes[i].url;
    if (window.location.href.indexOf(dir + subDir) !== -1) {
      View = routes[i].ui.View;
      name = routes[i].name;
      // @ts-ignore
      secondary = routes[i].secondary;
    }
  }
  return {
    name,
    View,
    secondary,
  };
};

export default getActiveView;

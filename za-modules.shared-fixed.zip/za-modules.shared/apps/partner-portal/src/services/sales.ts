import { useState, useEffect } from 'react';
import axios from 'axios';

interface SalesData {
  series: {
    data: number[];
    name: string;
  }[];
  xaxis: {
    categories: string[];
    type: string;
  };
}

const useSales = () => {
  const [sales, setNewSales] = useState<SalesData>({
    series: [
      {
        data: [31, 40, 28, 51, 42, 109, 100],
        name: 'sales',
      },
      {
        data: [11, 32, 45, 32, 34, 52, 41],
        name: 'clicks',
      },
    ],
    xaxis: {
      categories: [
        '2018-09-19T00:00:00.000Z',
        '2018-09-19T01:30:00.000Z',
        '2018-09-19T02:30:00.000Z',
        '2018-09-19T03:30:00.000Z',
        '2018-09-19T04:30:00.000Z',
        '2018-09-19T05:30:00.000Z',
        '2018-09-19T06:30:00.000Z',
      ],
      type: 'datetime',
    },
  });

  useEffect(() => {
    getSales();
  }, []);

  function getSales() {
    axios({
      method: 'GET',
      url: 'http://192.168.48.88:8888/sales',
    })
      .then((response) => {
        const data = response.data;
        setNewSales(data);
      })
      .catch((error) => {
        if (error.response) {
          console.log(error.response);
          console.log(error.response.status);
          console.log(error.response.headers);
        }
      });
  }

  return sales;
};

export default useSales;

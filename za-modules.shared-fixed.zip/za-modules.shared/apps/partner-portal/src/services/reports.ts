import { useState, useEffect } from 'react';
import axios from 'axios';

interface DataItem {
  file_name: string;
  last_modified: string;
}

interface ReportsData {
  data: DataItem[];
}


const useReports = () => {
  const [reports, setNewReports] = useState<ReportsData>({
    data: [
      {
        file_name: 'ff1.txt',
        last_modified: 'Thu, 24 Aug 2023 12:49:54 GMT',
      },
      {
        file_name: 'ff2.txt',
        last_modified: 'Thu, 24 Aug 2023 13:06:38 GMT',
      },
      {
        file_name: 'test.json',
        last_modified: 'Thu, 24 Aug 2023 12:44:10 GMT',
      },
    ],
  });

  useEffect(() => {
    getReports();
  }, []);

  function getReports() {
    axios({
      method: 'GET',
      url: 'http://192.168.48.67:8888/get_reports',
    })
      .then((response) => {
        const data = response.data;
        setNewReports(data);
      })
      .catch((error) => {
        if (error.response) {
          console.log(error.response);
          console.log(error.response.status);
          console.log(error.response.headers);
        }
      });
  }

  return { reports, getReports };
};

export default useReports;

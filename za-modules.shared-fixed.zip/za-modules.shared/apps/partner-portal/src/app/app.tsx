import { Box, useColorModeValue } from '@chakra-ui/react';

import { Route, Routes } from 'react-router-dom';
import routes from '../routes';

export const App = () => {
  return (
    <main>
      <Box minH="100vh" bg={useColorModeValue('gray.100', 'gray.900')}>
        <Routes>
          {routes.map(({ ui: { Layout }, url: { dir, subDir } }) => (
            // @ts-ignore
            <Route key={dir + subDir} path={dir + subDir} element={<Layout />} />
          ))}
        </Routes>
      </Box>
    </main>
  );
};

export default App;

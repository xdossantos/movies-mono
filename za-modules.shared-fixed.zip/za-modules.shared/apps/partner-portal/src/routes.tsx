import { Icon } from '@chakra-ui/react';
import {  MdHome } from 'react-icons/md';

// Admin Imports
import MainDashboard from './views/admin/default';
import { ReactNode } from "react";
import AdminLayout from './layouts/admin';

const routes: RoutesType[] = [
  {
    name: 'Home',
    icon: <Icon as={MdHome} width="20px" height="20px" color="inherit" />,
    component: MainDashboard as unknown as ReactNode,
    ui: {
      Layout: AdminLayout as unknown as ReactNode,
      View: MainDashboard as unknown as ReactNode,
    },
    url : {
      dir: '/admin',
      subDir: '/home',
    }
  },
  {
    name: 'Main Dashboard',
    icon: <Icon as={MdHome} width="20px" height="20px" color="inherit" />,
    component: MainDashboard as unknown as ReactNode,
    ui: {
      Layout: AdminLayout as unknown as ReactNode,
      View: MainDashboard as unknown as ReactNode,
    },
    url : {
      dir: '/admin',
      subDir: '/default',
    }
  },
];



export default routes;

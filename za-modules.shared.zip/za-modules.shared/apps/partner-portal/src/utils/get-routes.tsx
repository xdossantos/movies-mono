import { Route, Routes } from 'react-router-dom';

const getRoutes = (routes: RoutesType[], layout = '/admin'): any => {
  return routes.map((route: RoutesType, key: any) => {
    if (route.layout.path === layout) {
      return (
        <Route
          path={route.layout.path + route.subdirectory}
          element={route.layout.Component}
          key={key}
        />
      );
    } else {
      return null;
    }
  });
};

export default getRoutes;

import { Route, Routes } from 'react-router-dom';

const getRoutes = (routes: RoutesType[], layout = '/admin'): any => {
  return routes.map((route: RoutesType, key: any) => {
    if (route.layout === layout) {
      return (
        <Route
          path={route.layout + route.path}
          element={route.component}
          key={key}
        />
      );
    } else {
      return null;
    }
  });
};

export default getRoutes;

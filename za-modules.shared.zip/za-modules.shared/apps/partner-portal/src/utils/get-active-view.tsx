import { Route, Routes } from 'react-router-dom';
import { ReactNode } from "react";

const getActiveView = (routes: RoutesType[]): ReactNode | null  => {
  let activeView = null;
  for (let i = 0; i < routes.length; i++) {
    if (
      window.location.href.indexOf(routes[i].layout + routes[i].path) !== -1
    ) {
      return routes[i].component;
    }
  }

  return activeView;
};

export default getActiveView;

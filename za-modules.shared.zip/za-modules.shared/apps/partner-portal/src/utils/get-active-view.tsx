const getActiveView = (routes: Array<RoutesType>): any => {
  let Component = null;
  let name = 'Default Path Text';
  let secondary = false;

  for (let i = 0; i < routes.length; i++) {
    if (
      window.location.href.indexOf(
        routes[i].layout.path + routes[i].subdirectory
      ) !== -1
    ) {
      Component = routes[i].layout.Component;
      name = routes[i].name;
      secondary = routes[i].secondary;
    }
  }

  return {
    name,
    Component,
    secondary,
  };
};

export default getActiveView;

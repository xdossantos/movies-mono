import { useState, useEffect } from 'react';
import axios from 'axios';

interface RulesData {
  UNIFI_ST: string[];
}

const useRules = () => {
  const [rules, setNewRules] = useState<RulesData>({
    UNIFI_ST: [
      'CREDIT_SCORE GreaterThan 570 AND LessThan 630',
      'MONTHLY_SALARY GreaterThanOrEqual 4500',
      'EMPLOYMENT_STATUS in Vector(FT_EMPLOYED)',
      'AGE of min 18 and max 64',
      'NO_COURT_JUDGMENTS',
      'NO_FRAUD_WARNINGS',
      'NO_BANKRUPTCIES',
      'NO_VOLUNTARY_ARRANGEMENTS',
      'NO_DEBT_RESTRUCTURING',
      'BANKS_WITH Vector(STANDARDBANK, FIRSTNATIONALBANK, ABSA, CAPITEC, NEDBANK, AFRICANBANK)',
    ],
  });

  useEffect(() => {
    getRules();
  }, []);

  function getRules() {
    axios({
      method: 'GET',
      url: 'http://192.168.48.102:9000/v1/view/filters/unifi',
    })
      .then((response) => {
        const data = response.data;
        setNewRules(data);
      })
      .catch((error) => {
        if (error.response) {
          console.log(error.response);
          console.log(error.response.status);
          console.log(error.response.headers);
        }
      });
  }

  return {rules, getRules};
};

export default useRules;

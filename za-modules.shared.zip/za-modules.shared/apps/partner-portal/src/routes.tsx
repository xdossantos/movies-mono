import { Icon } from '@chakra-ui/react';
import { MdHome } from 'react-icons/md';

// Admin Imports
import MainDashboard from './views/admin/default';
import AdminLayout from './layouts/admin';

import { ReactNode } from 'react';

const routes: RoutesType[] = [
  {
    name: 'Main Dashboard',
    layout: { path: '/', Component: AdminLayout as unknown as ReactNode },
    subdirectory: '',
    icon: <Icon as={MdHome} width="20px" height="20px" color="inherit" />,
    View: MainDashboard as unknown as ReactNode,
  },
  {
    name: 'Main Dashboard',
    layout: { path: '/admin', Component: AdminLayout as unknown as ReactNode },
    subdirectory: '',
    icon: <Icon as={MdHome} width="20px" height="20px" color="inherit" />,
    View: MainDashboard as unknown as ReactNode,
  },
  {
    name: 'Main Dashboard',
    layout: { path: '/admin', Component: AdminLayout as unknown as ReactNode },
    subdirectory: '/default',
    icon: <Icon as={MdHome} width="20px" height="20px" color="inherit" />,
    View: MainDashboard as unknown as ReactNode,
  },
];

export default routes;

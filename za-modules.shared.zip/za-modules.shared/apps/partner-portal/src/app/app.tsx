import { Box, Link, useColorModeValue } from '@chakra-ui/react';

import { Route, Routes } from 'react-router-dom';
import AdminLayout from '../layouts/admin';

export const App = () => {
  return (
    <main>
      <Box minH="100vh" bg={useColorModeValue('gray.100', 'gray.900')}>
        <Routes>
          <Route
            path="/"
            element={
              <div>
                This is the generated root route.{' '}
                <Link to="/page-2">Click here for page 2.</Link>
              </div>
            }
          />
          <Route
            path="/admin"
            element={<AdminLayout />}
          />
          {/*TODO: Add dynamic routing here via a util */}
          <Route
            path="/admin/default"
            element={<AdminLayout />}
          />
          <Route
            path="/page-2"
            element={
              <div>
                <Link to="/">Click here to go back to root page.</Link>
              </div>
            }
          />
        </Routes>
      </Box>
    </main>
  );
};

export default App;

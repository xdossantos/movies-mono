import { Box, useColorModeValue } from '@chakra-ui/react';

import { Route, Routes } from 'react-router-dom';
import routes from '../routes';
import AdminLayout from "../layouts/admin";

export const App = () => {
  return (
    <main>
      <Box minH="100vh" bg={useColorModeValue('gray.100', 'gray.900')}>
        <AdminLayout/>
        {/*<Routes>*/}
        {/*  {routes.map(({ layout: { path, Component }, subdirectory }) => (*/}
        {/*    <Route*/}
        {/*      key={path + subdirectory}*/}
        {/*      path={path + subdirectory}*/}
        {/*      element={<Component />}*/}
        {/*    />*/}
        {/*  ))}*/}
        {/*</Routes>*/}
      </Box>
    </main>
  );
};

export default App;

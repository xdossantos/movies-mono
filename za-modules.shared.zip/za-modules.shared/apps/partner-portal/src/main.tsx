// import { createRoot } from 'react-dom';
import App from './app/app';
import React from 'react';
import { ChakraProvider } from '@chakra-ui/react';
import { BrowserRouter } from 'react-router-dom';

import theme from './theme/theme';
import Fonts from './theme/fonts';
import { createRoot } from "react-dom/client";

const rootElement = document.getElementById('root');

// @ts-ignore
createRoot(rootElement).render(
  <ChakraProvider theme={theme}>
    <Fonts />
    <React.StrictMode>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </React.StrictMode>
  </ChakraProvider>
);

import { hooks } from './hooks';

describe('hooks', () => {
  it('should work', () => {
    expect(hooks()).toEqual('hooks');
  });
});

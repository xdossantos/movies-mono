export function hooks(): string {
  return 'hooks';
}
